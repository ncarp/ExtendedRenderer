// *****************************************************************************
// 
//  © Component Factory Pty Ltd 2008. All rights reserved.
//	The software and associated documentation supplied hereunder are the 
//  proprietary information of Component Factory Pty Ltd, PO Box 1504, 
//  Glen Waverley, Vic 3150, Australia and are supplied subject to licence terms.
// 
//  Version 2.8.5.0 	www.ComponentFactory.com
// *****************************************************************************

using System;
using System.Text;
using System.Drawing;
using System.Windows.Forms;
using System.ComponentModel;
using System.Collections.Generic;
using System.Diagnostics;
using ComponentFactory.Krypton.Toolkit;
using AC.ExtendedRenderer.Navigator;

namespace $rootnamespace$
{
    public partial class $safeitemname$ : KryptonForm
    {
        public $safeitemname$()
        {
            InitializeComponent();
        }

        private int _storeSplitterDistance;
        private int _StoreHeaderWidth;
        private bool _isCollapsed = false;

        private void Form1_Load(object sender, EventArgs e)
        {
            _storeSplitterDistance = this.KryptonSplitContainerMain.SplitterDistance;
            _StoreHeaderWidth = this.kryptonHeaderCollapser.Height;


            this.outlookBar1.Buttons[0].Selected = true;
            kryptonHeaderCollapser.Values.Heading = this.outlookBar1.SelectedButton.ToString();
            kryptonHeaderGroup.ValuesPrimary.Heading = this.outlookBar1.SelectedButton.ToString();
        }
        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void tsbExit_Click(object sender, EventArgs e)
        {
            Close();
        }


        private void outlookBar1_ButtonClicked_1(object sender, EventArgs e)
        {
            OutlookBar ob = (OutlookBar)sender;
            this.kryptonEmptyTabControl1.SelectedTab = kryptonEmptyTabControl1.TabPages[ob.SelectedButton.BuddyPage1];
            this.kryptonEmptyTabControl2.SelectedTab = kryptonEmptyTabControl2.TabPages[ob.SelectedButton.BuddyPage2];

            kryptonHeaderCollapser.Values.Heading = ob.SelectedButton.ToString();
            this.kryptonHeaderGroup.ValuesPrimary.Heading = ob.SelectedButton.ToString();
        }

        private void buttonSpecAny1_Click(object sender, EventArgs e)
        {
            _isCollapsed = SetOutlookBarMiniMode(_isCollapsed);
        }

        private bool SetOutlookBarMiniMode(bool toogleValue)
        {
            if (toogleValue)
            {
                this.KryptonSplitContainerMain.FixedPanel = FixedPanel.Panel1;
                this.KryptonSplitContainerMain.SplitterDistance = _storeSplitterDistance;
                this.buttonSpecAny1.Type = ComponentFactory.Krypton.Toolkit.PaletteButtonSpecStyle.ArrowLeft;
                this.kryptonHeaderCollapser.ButtonSpecs[0].Edge = PaletteRelativeEdgeAlign.Inherit;
                this.kryptonHeaderCollapser.Orientation = VisualOrientation.Top;
                this.kryptonHeaderCollapser.AutoSize = true;
                this.kryptonHeaderCollapser.Height = _StoreHeaderWidth;
                this.kryptonHeaderCollapser.StateNormal.Border.DrawBorders = PaletteDrawBorders.TopLeftRight;
            }
            else
            {
                this.KryptonSplitContainerMain.FixedPanel = FixedPanel.Panel1;
                this.KryptonSplitContainerMain.SplitterDistance = 44;
                this.buttonSpecAny1.Type = ComponentFactory.Krypton.Toolkit.PaletteButtonSpecStyle.ArrowRight;
                this.kryptonHeaderCollapser.ButtonSpecs[0].Edge = PaletteRelativeEdgeAlign.Near;
                this.kryptonHeaderCollapser.Orientation = VisualOrientation.Right;
                this.kryptonHeaderCollapser.AutoSize = false;
                this.kryptonHeaderCollapser.Height = KryptonSplitContainerMain.Panel1.Height - this.outlookBar1.Height;// -12;
                this.kryptonHeaderCollapser.StateNormal.Border.DrawBorders = PaletteDrawBorders.All;
            }
            return !toogleValue;
        }



    }
}
