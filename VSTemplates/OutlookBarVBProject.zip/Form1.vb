Imports AC.ExtendedRenderer.Navigator
Imports ComponentFactory.Krypton.Toolkit

Public Class Form1

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        _storeSplitterDistance = Me.KryptonSplitContainerMain.SplitterDistance
        _StoreHeaderWidth = Me.kryptonHeaderCollapser.Height

        Me.outlookBar1.Buttons(0).Selected = True
        kryptonHeaderCollapser.Values.Heading = Me.outlookBar1.SelectedButton.ToString()
        kryptonHeaderGroup.ValuesPrimary.Heading = Me.outlookBar1.SelectedButton.ToString()
    End Sub

#Region "   Declarations   "
    Private _storeSplitterDistance As Integer
    Private _StoreHeaderWidth As Integer
    Private _isCollapsed As Boolean = False
#End Region

#Region "   Outlook Bar Management   "

    Private Sub buttonSpecAny1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles buttonSpecAny1.Click
        _isCollapsed = SetOutlookBarMiniMode(_isCollapsed)
    End Sub


    Private Sub outlookBar1_ButtonClicked(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles outlookBar1.ButtonClicked
        Dim ob As OutlookBar = CType(sender, OutlookBar)
        Me.kryptonEmptyTabControl1.SelectedTab = kryptonEmptyTabControl1.TabPages(ob.SelectedButton.BuddyPage1)
        Me.kryptonEmptyTabControl2.SelectedTab = kryptonEmptyTabControl2.TabPages(ob.SelectedButton.BuddyPage2)

        kryptonHeaderCollapser.Values.Heading = ob.SelectedButton.ToString()
        Me.kryptonHeaderGroup.ValuesPrimary.Heading = ob.SelectedButton.ToString()
    End Sub

    Private Function SetOutlookBarMiniMode(ByVal toogleValue As Boolean) As Boolean

        If (toogleValue) Then

            Me.KryptonSplitContainerMain.FixedPanel = FixedPanel.Panel1
            Me.KryptonSplitContainerMain.SplitterDistance = _storeSplitterDistance
            Me.buttonSpecAny1.Type = ComponentFactory.Krypton.Toolkit.PaletteButtonSpecStyle.ArrowLeft
            Me.kryptonHeaderCollapser.ButtonSpecs(0).Edge = PaletteRelativeEdgeAlign.Inherit
            Me.kryptonHeaderCollapser.Orientation = VisualOrientation.Top
            Me.kryptonHeaderCollapser.AutoSize = True
            Me.kryptonHeaderCollapser.Height = _StoreHeaderWidth
            Me.kryptonHeaderCollapser.StateNormal.Border.DrawBorders = PaletteDrawBorders.TopLeftRight

        Else
            Me.KryptonSplitContainerMain.FixedPanel = FixedPanel.Panel1
            Me.KryptonSplitContainerMain.SplitterDistance = 44
            Me.buttonSpecAny1.Type = ComponentFactory.Krypton.Toolkit.PaletteButtonSpecStyle.ArrowRight
            Me.kryptonHeaderCollapser.ButtonSpecs(0).Edge = PaletteRelativeEdgeAlign.Near
            Me.kryptonHeaderCollapser.Orientation = VisualOrientation.Right
            Me.kryptonHeaderCollapser.AutoSize = False
            Me.kryptonHeaderCollapser.Height = KryptonSplitContainerMain.Panel1.Height - Me.outlookBar1.Height ' -12;
            Me.kryptonHeaderCollapser.StateNormal.Border.DrawBorders = PaletteDrawBorders.All
        End If
        Return Not toogleValue
    End Function
#End Region

#Region "   Menu Items   "

    Private Sub tsbExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsbExit.Click
        Close()
    End Sub

    Private Sub closeToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles closeToolStripMenuItem.Click
        Close()
    End Sub
#End Region

End Class
