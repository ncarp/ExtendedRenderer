<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits ComponentFactory.Krypton.Toolkit.KryptonForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim OutlookBarButton1 As AC.ExtendedRenderer.Navigator.OutlookBarButton = New AC.ExtendedRenderer.Navigator.OutlookBarButton
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Dim OutlookBarButton2 As AC.ExtendedRenderer.Navigator.OutlookBarButton = New AC.ExtendedRenderer.Navigator.OutlookBarButton
        Me.KryptonManager1 = New ComponentFactory.Krypton.Toolkit.KryptonManager(Me.components)
        Me.toolStripContainer1 = New System.Windows.Forms.ToolStripContainer
        Me.KryptonSplitContainerMain = New ComponentFactory.Krypton.Toolkit.KryptonSplitContainer
        Me.kryptonPanelMain = New ComponentFactory.Krypton.Toolkit.KryptonPanel
        Me.kryptonEmptyTabControl1 = New AC.ExtendedRenderer.Navigator.KryptonEmptyTabControl(Me.components)
        Me.tabPage1a = New System.Windows.Forms.TabPage
        Me.tabPage2a = New System.Windows.Forms.TabPage
        Me.outlookBar1 = New AC.ExtendedRenderer.Navigator.OutlookBar
        Me.kryptonHeaderCollapser = New ComponentFactory.Krypton.Toolkit.KryptonHeader
        Me.buttonSpecAny1 = New ComponentFactory.Krypton.Toolkit.ButtonSpecAny
        Me.kryptonHeaderGroup = New ComponentFactory.Krypton.Toolkit.KryptonHeaderGroup
        Me.kryptonEmptyTabControl2 = New AC.ExtendedRenderer.Navigator.KryptonEmptyTabControl(Me.components)
        Me.tabPage1b = New System.Windows.Forms.TabPage
        Me.tabPage2b = New System.Windows.Forms.TabPage
        Me.toolStrip = New System.Windows.Forms.ToolStrip
        Me.tsbExit = New System.Windows.Forms.ToolStripButton
        Me.menuStrip = New System.Windows.Forms.MenuStrip
        Me.fileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.closeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip
        Me.toolStripContainer1.ContentPanel.SuspendLayout()
        Me.toolStripContainer1.TopToolStripPanel.SuspendLayout()
        Me.toolStripContainer1.SuspendLayout()
        CType(Me.KryptonSplitContainerMain, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.KryptonSplitContainerMain.Panel1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.KryptonSplitContainerMain.Panel1.SuspendLayout()
        CType(Me.KryptonSplitContainerMain.Panel2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.KryptonSplitContainerMain.Panel2.SuspendLayout()
        Me.KryptonSplitContainerMain.SuspendLayout()
        CType(Me.kryptonPanelMain, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.kryptonPanelMain.SuspendLayout()
        Me.kryptonEmptyTabControl1.SuspendLayout()
        CType(Me.kryptonHeaderGroup, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.kryptonHeaderGroup.Panel, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.kryptonHeaderGroup.Panel.SuspendLayout()
        Me.kryptonHeaderGroup.SuspendLayout()
        Me.kryptonEmptyTabControl2.SuspendLayout()
        Me.toolStrip.SuspendLayout()
        Me.menuStrip.SuspendLayout()
        Me.SuspendLayout()
        '
        'toolStripContainer1
        '
        '
        'toolStripContainer1.ContentPanel
        '
        Me.toolStripContainer1.ContentPanel.Controls.Add(Me.KryptonSplitContainerMain)
        Me.toolStripContainer1.ContentPanel.Size = New System.Drawing.Size(593, 338)
        Me.toolStripContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.toolStripContainer1.Location = New System.Drawing.Point(0, 0)
        Me.toolStripContainer1.Name = "toolStripContainer1"
        Me.toolStripContainer1.Size = New System.Drawing.Size(593, 387)
        Me.toolStripContainer1.TabIndex = 6
        Me.toolStripContainer1.Text = "toolStripContainer1"
        '
        'toolStripContainer1.TopToolStripPanel
        '
        Me.toolStripContainer1.TopToolStripPanel.Controls.Add(Me.toolStrip)
        Me.toolStripContainer1.TopToolStripPanel.Controls.Add(Me.menuStrip)
        '
        'KryptonSplitContainerMain
        '
        Me.KryptonSplitContainerMain.Cursor = System.Windows.Forms.Cursors.Default
        Me.KryptonSplitContainerMain.Dock = System.Windows.Forms.DockStyle.Fill
        Me.KryptonSplitContainerMain.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.KryptonSplitContainerMain.Location = New System.Drawing.Point(0, 0)
        Me.KryptonSplitContainerMain.Name = "KryptonSplitContainerMain"
        '
        'KryptonSplitContainerMain.Panel1
        '
        Me.KryptonSplitContainerMain.Panel1.Controls.Add(Me.kryptonPanelMain)
        '
        'KryptonSplitContainerMain.Panel2
        '
        Me.KryptonSplitContainerMain.Panel2.Controls.Add(Me.kryptonHeaderGroup)
        Me.KryptonSplitContainerMain.Size = New System.Drawing.Size(593, 338)
        Me.KryptonSplitContainerMain.SplitterDistance = 179
        Me.KryptonSplitContainerMain.SplitterWidth = 0
        Me.KryptonSplitContainerMain.TabIndex = 1
        '
        'kryptonPanelMain
        '
        Me.kryptonPanelMain.Controls.Add(Me.kryptonEmptyTabControl1)
        Me.kryptonPanelMain.Controls.Add(Me.outlookBar1)
        Me.kryptonPanelMain.Controls.Add(Me.kryptonHeaderCollapser)
        Me.kryptonPanelMain.Dock = System.Windows.Forms.DockStyle.Fill
        Me.kryptonPanelMain.Location = New System.Drawing.Point(0, 0)
        Me.kryptonPanelMain.Name = "kryptonPanelMain"
        Me.kryptonPanelMain.Size = New System.Drawing.Size(179, 338)
        Me.kryptonPanelMain.TabIndex = 0
        '
        'kryptonEmptyTabControl1
        '
        Me.kryptonEmptyTabControl1.Controls.Add(Me.tabPage1a)
        Me.kryptonEmptyTabControl1.Controls.Add(Me.tabPage2a)
        Me.kryptonEmptyTabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.kryptonEmptyTabControl1.DrawBorder = True
        Me.kryptonEmptyTabControl1.Location = New System.Drawing.Point(0, 30)
        Me.kryptonEmptyTabControl1.Name = "kryptonEmptyTabControl1"
        Me.kryptonEmptyTabControl1.SelectedIndex = 0
        Me.kryptonEmptyTabControl1.Size = New System.Drawing.Size(179, 204)
        Me.kryptonEmptyTabControl1.TabIndex = 10
        '
        'tabPage1a
        '
        Me.tabPage1a.BackColor = System.Drawing.Color.FromArgb(CType(CType(191, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.tabPage1a.Location = New System.Drawing.Point(4, 14)
        Me.tabPage1a.Name = "tabPage1a"
        Me.tabPage1a.Size = New System.Drawing.Size(171, 186)
        Me.tabPage1a.TabIndex = 0
        Me.tabPage1a.Text = "tabPage1a"
        Me.tabPage1a.UseVisualStyleBackColor = True
        '
        'tabPage2a
        '
        Me.tabPage2a.BackColor = System.Drawing.SystemColors.Window
        Me.tabPage2a.Location = New System.Drawing.Point(4, 14)
        Me.tabPage2a.Name = "tabPage2a"
        Me.tabPage2a.Size = New System.Drawing.Size(171, 175)
        Me.tabPage2a.TabIndex = 1
        Me.tabPage2a.Text = "tabPage2a"
        Me.tabPage2a.UseVisualStyleBackColor = True
        '
        'outlookBar1
        '
        Me.outlookBar1.ButtonColorHoveringBottom = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(239, Byte), Integer), CType(CType(177, Byte), Integer))
        Me.outlookBar1.ButtonColorHoveringTop = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(213, Byte), Integer), CType(CType(77, Byte), Integer))
        Me.outlookBar1.ButtonColorPassiveBottom = System.Drawing.Color.FromArgb(CType(CType(202, Byte), Integer), CType(CType(229, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.outlookBar1.ButtonColorPassiveTop = System.Drawing.Color.FromArgb(CType(CType(178, Byte), Integer), CType(CType(214, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.outlookBar1.ButtonColorSelectedAndHoveringBottom = System.Drawing.Color.FromArgb(CType(CType(252, Byte), Integer), CType(CType(207, Byte), Integer), CType(CType(100, Byte), Integer))
        Me.outlookBar1.ButtonColorSelectedAndHoveringTop = System.Drawing.Color.FromArgb(CType(CType(232, Byte), Integer), CType(CType(142, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.outlookBar1.ButtonColorSelectedBottom = System.Drawing.Color.FromArgb(CType(CType(254, Byte), Integer), CType(CType(195, Byte), Integer), CType(CType(108, Byte), Integer))
        Me.outlookBar1.ButtonColorSelectedTop = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(122, Byte), Integer), CType(CType(5, Byte), Integer))
        Me.outlookBar1.ButtonHeight = 35
        OutlookBarButton1.BuddyPage1 = "tabPage1a"
        OutlookBarButton1.BuddyPage2 = "tabPage1b"
        OutlookBarButton1.Image = CType(resources.GetObject("OutlookBarButton1.Image"), System.Drawing.Icon)
        OutlookBarButton1.Selected = True
        OutlookBarButton1.Tag1 = Nothing
        OutlookBarButton1.Tag2 = Nothing
        OutlookBarButton1.Text = "Button1"
        OutlookBarButton2.BuddyPage1 = "tabPage2a"
        OutlookBarButton2.BuddyPage2 = "tabPage2b"
        OutlookBarButton2.Image = CType(resources.GetObject("OutlookBarButton2.Image"), System.Drawing.Icon)
        OutlookBarButton2.Tag1 = Nothing
        OutlookBarButton2.Tag2 = Nothing
        OutlookBarButton2.Text = "Button2"
        Me.outlookBar1.Buttons.Add(OutlookBarButton1)
        Me.outlookBar1.Buttons.Add(OutlookBarButton2)
        Me.outlookBar1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.outlookBar1.DrawBorders = True
        Me.outlookBar1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(66, Byte), Integer), CType(CType(139, Byte), Integer))
        Me.outlookBar1.ForeColorSelected = System.Drawing.Color.FromArgb(CType(CType(21, Byte), Integer), CType(CType(66, Byte), Integer), CType(CType(139, Byte), Integer))
        Me.outlookBar1.Location = New System.Drawing.Point(0, 234)
        Me.outlookBar1.MinimumSize = New System.Drawing.Size(16, 40)
        Me.outlookBar1.Name = "outlookBar1"
        Me.outlookBar1.OutlookBarLineColor = System.Drawing.Color.FromArgb(CType(CType(111, Byte), Integer), CType(CType(157, Byte), Integer), CType(CType(217, Byte), Integer))
        Me.outlookBar1.RemoveTopBorder = True
        Me.outlookBar1.Renderer = AC.ExtendedRenderer.Navigator.Renderer.Krypton
        Me.outlookBar1.Size = New System.Drawing.Size(179, 104)
        Me.outlookBar1.TabIndex = 11
        Me.outlookBar1.Text = "outlookBar1"
        '
        'kryptonHeaderCollapser
        '
        Me.kryptonHeaderCollapser.ButtonSpecs.AddRange(New ComponentFactory.Krypton.Toolkit.ButtonSpecAny() {Me.buttonSpecAny1})
        Me.kryptonHeaderCollapser.Dock = System.Windows.Forms.DockStyle.Top
        Me.kryptonHeaderCollapser.Location = New System.Drawing.Point(0, 0)
        Me.kryptonHeaderCollapser.Name = "kryptonHeaderCollapser"
        Me.kryptonHeaderCollapser.Size = New System.Drawing.Size(179, 30)
        Me.kryptonHeaderCollapser.StateNormal.Border.DrawBorders = CType(((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top Or ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) _
                    Or ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right), ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)
        Me.kryptonHeaderCollapser.TabIndex = 13
        Me.kryptonHeaderCollapser.Text = "  "
        Me.kryptonHeaderCollapser.Values.Description = ""
        Me.kryptonHeaderCollapser.Values.Heading = "  "
        Me.kryptonHeaderCollapser.Values.Image = Nothing
        '
        'buttonSpecAny1
        '
        Me.buttonSpecAny1.ExtraText = ""
        Me.buttonSpecAny1.Image = Nothing
        Me.buttonSpecAny1.Text = ""
        Me.buttonSpecAny1.Type = ComponentFactory.Krypton.Toolkit.PaletteButtonSpecStyle.ArrowLeft
        Me.buttonSpecAny1.UniqueName = "C18E250E4E8343ADC18E250E4E8343AD"
        '
        'kryptonHeaderGroup
        '
        Me.kryptonHeaderGroup.Dock = System.Windows.Forms.DockStyle.Fill
        Me.kryptonHeaderGroup.HeaderVisibleSecondary = False
        Me.kryptonHeaderGroup.Location = New System.Drawing.Point(0, 0)
        Me.kryptonHeaderGroup.Name = "kryptonHeaderGroup"
        '
        'kryptonHeaderGroup.Panel
        '
        Me.kryptonHeaderGroup.Panel.Controls.Add(Me.kryptonEmptyTabControl2)
        Me.kryptonHeaderGroup.Size = New System.Drawing.Size(414, 338)
        Me.kryptonHeaderGroup.TabIndex = 1
        Me.kryptonHeaderGroup.Text = "  "
        Me.kryptonHeaderGroup.ValuesPrimary.Description = ""
        Me.kryptonHeaderGroup.ValuesPrimary.Heading = "  "
        Me.kryptonHeaderGroup.ValuesPrimary.Image = CType(resources.GetObject("kryptonHeaderGroup.ValuesPrimary.Image"), System.Drawing.Image)
        Me.kryptonHeaderGroup.ValuesSecondary.Description = ""
        Me.kryptonHeaderGroup.ValuesSecondary.Heading = "Description"
        Me.kryptonHeaderGroup.ValuesSecondary.Image = Nothing
        '
        'kryptonEmptyTabControl2
        '
        Me.kryptonEmptyTabControl2.Controls.Add(Me.tabPage1b)
        Me.kryptonEmptyTabControl2.Controls.Add(Me.tabPage2b)
        Me.kryptonEmptyTabControl2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.kryptonEmptyTabControl2.DrawBorder = False
        Me.kryptonEmptyTabControl2.Location = New System.Drawing.Point(0, 0)
        Me.kryptonEmptyTabControl2.Margin = New System.Windows.Forms.Padding(0)
        Me.kryptonEmptyTabControl2.Name = "kryptonEmptyTabControl2"
        Me.kryptonEmptyTabControl2.SelectedIndex = 0
        Me.kryptonEmptyTabControl2.Size = New System.Drawing.Size(412, 306)
        Me.kryptonEmptyTabControl2.TabIndex = 0
        '
        'tabPage1b
        '
        Me.tabPage1b.BackColor = System.Drawing.Color.FromArgb(CType(CType(191, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.tabPage1b.Location = New System.Drawing.Point(4, 14)
        Me.tabPage1b.Margin = New System.Windows.Forms.Padding(0)
        Me.tabPage1b.Name = "tabPage1b"
        Me.tabPage1b.Size = New System.Drawing.Size(404, 288)
        Me.tabPage1b.TabIndex = 0
        Me.tabPage1b.Text = "tabPage1b"
        Me.tabPage1b.UseVisualStyleBackColor = True
        '
        'tabPage2b
        '
        Me.tabPage2b.BackColor = System.Drawing.SystemColors.Window
        Me.tabPage2b.Location = New System.Drawing.Point(4, 14)
        Me.tabPage2b.Margin = New System.Windows.Forms.Padding(0)
        Me.tabPage2b.Name = "tabPage2b"
        Me.tabPage2b.Size = New System.Drawing.Size(398, 277)
        Me.tabPage2b.TabIndex = 1
        Me.tabPage2b.Text = "tabPage2b"
        Me.tabPage2b.UseVisualStyleBackColor = True
        '
        'toolStrip
        '
        Me.toolStrip.Dock = System.Windows.Forms.DockStyle.None
        Me.toolStrip.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.toolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsbExit})
        Me.toolStrip.Location = New System.Drawing.Point(3, 24)
        Me.toolStrip.Name = "toolStrip"
        Me.toolStrip.Size = New System.Drawing.Size(52, 25)
        Me.toolStrip.TabIndex = 3
        Me.toolStrip.Text = "toolStrip"
        '
        'tsbExit
        '
        Me.tsbExit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.tsbExit.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbExit.Name = "tsbExit"
        Me.tsbExit.Size = New System.Drawing.Size(40, 22)
        Me.tsbExit.Text = "Close"
        '
        'menuStrip
        '
        Me.menuStrip.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.menuStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.fileToolStripMenuItem})
        Me.menuStrip.Location = New System.Drawing.Point(0, 0)
        Me.menuStrip.Name = "menuStrip"
        Me.menuStrip.Size = New System.Drawing.Size(593, 24)
        Me.menuStrip.TabIndex = 5
        Me.menuStrip.Text = "menuStrip"
        '
        'fileToolStripMenuItem
        '
        Me.fileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.closeToolStripMenuItem})
        Me.fileToolStripMenuItem.Name = "fileToolStripMenuItem"
        Me.fileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.fileToolStripMenuItem.Text = "File"
        '
        'closeToolStripMenuItem
        '
        Me.closeToolStripMenuItem.Name = "closeToolStripMenuItem"
        Me.closeToolStripMenuItem.Size = New System.Drawing.Size(92, 22)
        Me.closeToolStripMenuItem.Text = "Exit"
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 387)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.ManagerRenderMode
        Me.StatusStrip1.Size = New System.Drawing.Size(593, 22)
        Me.StatusStrip1.TabIndex = 7
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(593, 409)
        Me.Controls.Add(Me.toolStripContainer1)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.toolStripContainer1.ContentPanel.ResumeLayout(False)
        Me.toolStripContainer1.TopToolStripPanel.ResumeLayout(False)
        Me.toolStripContainer1.TopToolStripPanel.PerformLayout()
        Me.toolStripContainer1.ResumeLayout(False)
        Me.toolStripContainer1.PerformLayout()
        CType(Me.KryptonSplitContainerMain.Panel1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.KryptonSplitContainerMain.Panel1.ResumeLayout(False)
        CType(Me.KryptonSplitContainerMain.Panel2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.KryptonSplitContainerMain.Panel2.ResumeLayout(False)
        CType(Me.KryptonSplitContainerMain, System.ComponentModel.ISupportInitialize).EndInit()
        Me.KryptonSplitContainerMain.ResumeLayout(False)
        CType(Me.kryptonPanelMain, System.ComponentModel.ISupportInitialize).EndInit()
        Me.kryptonPanelMain.ResumeLayout(False)
        Me.kryptonPanelMain.PerformLayout()
        Me.kryptonEmptyTabControl1.ResumeLayout(False)
        CType(Me.kryptonHeaderGroup.Panel, System.ComponentModel.ISupportInitialize).EndInit()
        Me.kryptonHeaderGroup.Panel.ResumeLayout(False)
        CType(Me.kryptonHeaderGroup, System.ComponentModel.ISupportInitialize).EndInit()
        Me.kryptonHeaderGroup.ResumeLayout(False)
        Me.kryptonEmptyTabControl2.ResumeLayout(False)
        Me.toolStrip.ResumeLayout(False)
        Me.toolStrip.PerformLayout()
        Me.menuStrip.ResumeLayout(False)
        Me.menuStrip.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents KryptonManager1 As ComponentFactory.Krypton.Toolkit.KryptonManager
    Private WithEvents toolStripContainer1 As System.Windows.Forms.ToolStripContainer
    Private WithEvents KryptonSplitContainerMain As ComponentFactory.Krypton.Toolkit.KryptonSplitContainer
    Private WithEvents kryptonPanelMain As ComponentFactory.Krypton.Toolkit.KryptonPanel
    Private WithEvents kryptonEmptyTabControl1 As AC.ExtendedRenderer.Navigator.KryptonEmptyTabControl
    Private WithEvents tabPage1a As System.Windows.Forms.TabPage
    Private WithEvents tabPage2a As System.Windows.Forms.TabPage
    Private WithEvents outlookBar1 As AC.ExtendedRenderer.Navigator.OutlookBar
    Private WithEvents kryptonHeaderCollapser As ComponentFactory.Krypton.Toolkit.KryptonHeader
    Private WithEvents buttonSpecAny1 As ComponentFactory.Krypton.Toolkit.ButtonSpecAny
    Private WithEvents kryptonHeaderGroup As ComponentFactory.Krypton.Toolkit.KryptonHeaderGroup
    Private WithEvents kryptonEmptyTabControl2 As AC.ExtendedRenderer.Navigator.KryptonEmptyTabControl
    Private WithEvents tabPage1b As System.Windows.Forms.TabPage
    Private WithEvents tabPage2b As System.Windows.Forms.TabPage
    Private WithEvents toolStrip As System.Windows.Forms.ToolStrip
    Private WithEvents tsbExit As System.Windows.Forms.ToolStripButton
    Private WithEvents menuStrip As System.Windows.Forms.MenuStrip
    Private WithEvents fileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents closeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip

End Class
