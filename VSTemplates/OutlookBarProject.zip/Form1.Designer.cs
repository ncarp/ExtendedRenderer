namespace ChildControlStack
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            AC.ExtendedRenderer.Navigator.OutlookBarButton outlookBarButton1 = new AC.ExtendedRenderer.Navigator.OutlookBarButton();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            AC.ExtendedRenderer.Navigator.OutlookBarButton outlookBarButton2 = new AC.ExtendedRenderer.Navigator.OutlookBarButton();
            this.toolStrip = new System.Windows.Forms.ToolStrip();
            this.tsbExit = new System.Windows.Forms.ToolStripButton();
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.closeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripContainer1 = new System.Windows.Forms.ToolStripContainer();
            this.KryptonSplitContainerMain = new ComponentFactory.Krypton.Toolkit.KryptonSplitContainer();
            this.kryptonPanelMain = new ComponentFactory.Krypton.Toolkit.KryptonPanel();
            this.kryptonEmptyTabControl1 = new AC.ExtendedRenderer.Navigator.KryptonEmptyTabControl(this.components);
            this.tabPage1a = new System.Windows.Forms.TabPage();
            this.tabPage2a = new System.Windows.Forms.TabPage();
            this.outlookBar1 = new AC.ExtendedRenderer.Navigator.OutlookBar();
            this.kryptonHeaderCollapser = new ComponentFactory.Krypton.Toolkit.KryptonHeader();
            this.buttonSpecAny1 = new ComponentFactory.Krypton.Toolkit.ButtonSpecAny();
            this.kryptonHeaderGroup = new ComponentFactory.Krypton.Toolkit.KryptonHeaderGroup();
            this.kryptonEmptyTabControl2 = new AC.ExtendedRenderer.Navigator.KryptonEmptyTabControl(this.components);
            this.tabPage1b = new System.Windows.Forms.TabPage();
            this.tabPage2b = new System.Windows.Forms.TabPage();
            this.kryptonManager = new ComponentFactory.Krypton.Toolkit.KryptonManager(this.components);
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStrip.SuspendLayout();
            this.menuStrip.SuspendLayout();
            this.toolStripContainer1.ContentPanel.SuspendLayout();
            this.toolStripContainer1.TopToolStripPanel.SuspendLayout();
            this.toolStripContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.KryptonSplitContainerMain)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.KryptonSplitContainerMain.Panel1)).BeginInit();
            this.KryptonSplitContainerMain.Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.KryptonSplitContainerMain.Panel2)).BeginInit();
            this.KryptonSplitContainerMain.Panel2.SuspendLayout();
            this.KryptonSplitContainerMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanelMain)).BeginInit();
            this.kryptonPanelMain.SuspendLayout();
            this.kryptonEmptyTabControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonHeaderGroup)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonHeaderGroup.Panel)).BeginInit();
            this.kryptonHeaderGroup.Panel.SuspendLayout();
            this.kryptonHeaderGroup.SuspendLayout();
            this.kryptonEmptyTabControl2.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStrip
            // 
            this.toolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.toolStrip.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.toolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbExit});
            this.toolStrip.Location = new System.Drawing.Point(3, 24);
            this.toolStrip.Name = "toolStrip";
            this.toolStrip.Size = new System.Drawing.Size(52, 25);
            this.toolStrip.TabIndex = 3;
            this.toolStrip.Text = "toolStrip";
            // 
            // tsbExit
            // 
            this.tsbExit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbExit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbExit.Name = "tsbExit";
            this.tsbExit.Size = new System.Drawing.Size(40, 22);
            this.tsbExit.Text = "Close";
            this.tsbExit.Click += new System.EventHandler(this.tsbExit_Click);
            // 
            // menuStrip
            // 
            this.menuStrip.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Size = new System.Drawing.Size(668, 24);
            this.menuStrip.TabIndex = 0;
            this.menuStrip.Text = "menuStrip";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.closeToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // closeToolStripMenuItem
            // 
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new System.Drawing.Size(92, 22);
            this.closeToolStripMenuItem.Text = "Exit";
            this.closeToolStripMenuItem.Click += new System.EventHandler(this.closeToolStripMenuItem_Click);
            // 
            // toolStripContainer1
            // 
            // 
            // toolStripContainer1.ContentPanel
            // 
            this.toolStripContainer1.ContentPanel.Controls.Add(this.KryptonSplitContainerMain);
            this.toolStripContainer1.ContentPanel.Size = new System.Drawing.Size(668, 375);
            this.toolStripContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.toolStripContainer1.Location = new System.Drawing.Point(0, 0);
            this.toolStripContainer1.Name = "toolStripContainer1";
            this.toolStripContainer1.Size = new System.Drawing.Size(668, 424);
            this.toolStripContainer1.TabIndex = 4;
            this.toolStripContainer1.Text = "toolStripContainer1";
            // 
            // toolStripContainer1.TopToolStripPanel
            // 
            this.toolStripContainer1.TopToolStripPanel.Controls.Add(this.toolStrip);
            this.toolStripContainer1.TopToolStripPanel.Controls.Add(this.menuStrip);
            // 
            // KryptonSplitContainerMain
            // 
            this.KryptonSplitContainerMain.Cursor = System.Windows.Forms.Cursors.Default;
            this.KryptonSplitContainerMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.KryptonSplitContainerMain.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.KryptonSplitContainerMain.Location = new System.Drawing.Point(0, 0);
            this.KryptonSplitContainerMain.Name = "KryptonSplitContainerMain";
            // 
            // KryptonSplitContainerMain.Panel1
            // 
            this.KryptonSplitContainerMain.Panel1.Controls.Add(this.kryptonPanelMain);
            // 
            // KryptonSplitContainerMain.Panel2
            // 
            this.KryptonSplitContainerMain.Panel2.Controls.Add(this.kryptonHeaderGroup);
            this.KryptonSplitContainerMain.Size = new System.Drawing.Size(668, 375);
            this.KryptonSplitContainerMain.SplitterDistance = 179;
            this.KryptonSplitContainerMain.SplitterWidth = 0;
            this.KryptonSplitContainerMain.TabIndex = 1;
            // 
            // kryptonPanelMain
            // 
            this.kryptonPanelMain.Controls.Add(this.kryptonEmptyTabControl1);
            this.kryptonPanelMain.Controls.Add(this.outlookBar1);
            this.kryptonPanelMain.Controls.Add(this.kryptonHeaderCollapser);
            this.kryptonPanelMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kryptonPanelMain.Location = new System.Drawing.Point(0, 0);
            this.kryptonPanelMain.Name = "kryptonPanelMain";
            this.kryptonPanelMain.Size = new System.Drawing.Size(179, 375);
            this.kryptonPanelMain.TabIndex = 0;
            // 
            // kryptonEmptyTabControl1
            // 
            this.kryptonEmptyTabControl1.Controls.Add(this.tabPage1a);
            this.kryptonEmptyTabControl1.Controls.Add(this.tabPage2a);
            this.kryptonEmptyTabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kryptonEmptyTabControl1.DrawBorder = true;
            this.kryptonEmptyTabControl1.Location = new System.Drawing.Point(0, 30);
            this.kryptonEmptyTabControl1.Name = "kryptonEmptyTabControl1";
            this.kryptonEmptyTabControl1.SelectedIndex = 0;
            this.kryptonEmptyTabControl1.Size = new System.Drawing.Size(179, 241);
            this.kryptonEmptyTabControl1.TabIndex = 10;
            // 
            // tabPage1a
            // 
            this.tabPage1a.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.tabPage1a.Location = new System.Drawing.Point(4, 14);
            this.tabPage1a.Name = "tabPage1a";
            this.tabPage1a.Size = new System.Drawing.Size(171, 223);
            this.tabPage1a.TabIndex = 0;
            this.tabPage1a.Text = "tabPage1a";
            this.tabPage1a.UseVisualStyleBackColor = true;
            // 
            // tabPage2a
            // 
            this.tabPage2a.BackColor = System.Drawing.SystemColors.Window;
            this.tabPage2a.Location = new System.Drawing.Point(4, 14);
            this.tabPage2a.Name = "tabPage2a";
            this.tabPage2a.Size = new System.Drawing.Size(171, 245);
            this.tabPage2a.TabIndex = 1;
            this.tabPage2a.Text = "tabPage2a";
            this.tabPage2a.UseVisualStyleBackColor = true;
            // 
            // outlookBar1
            // 
            this.outlookBar1.ButtonColorHoveringBottom = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(239)))), ((int)(((byte)(177)))));
            this.outlookBar1.ButtonColorHoveringTop = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(213)))), ((int)(((byte)(77)))));
            this.outlookBar1.ButtonColorPassiveBottom = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.outlookBar1.ButtonColorPassiveTop = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(214)))), ((int)(((byte)(255)))));
            this.outlookBar1.ButtonColorSelectedAndHoveringBottom = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(207)))), ((int)(((byte)(100)))));
            this.outlookBar1.ButtonColorSelectedAndHoveringTop = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(142)))), ((int)(((byte)(49)))));
            this.outlookBar1.ButtonColorSelectedBottom = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(195)))), ((int)(((byte)(108)))));
            this.outlookBar1.ButtonColorSelectedTop = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(122)))), ((int)(((byte)(5)))));
            this.outlookBar1.ButtonHeight = 35;
            outlookBarButton1.BuddyPage1 = "tabPage1a";
            outlookBarButton1.BuddyPage2 = "tabPage1b";
            outlookBarButton1.Image = ((System.Drawing.Icon)(resources.GetObject("outlookBarButton1.Image")));
            outlookBarButton1.Selected = true;
            outlookBarButton1.Tag1 = null;
            outlookBarButton1.Tag2 = null;
            outlookBarButton1.Text = "Button1";
            outlookBarButton2.BuddyPage1 = "tabPage2a";
            outlookBarButton2.BuddyPage2 = "tabPage2b";
            outlookBarButton2.Image = ((System.Drawing.Icon)(resources.GetObject("outlookBarButton2.Image")));
            outlookBarButton2.Tag1 = null;
            outlookBarButton2.Tag2 = null;
            outlookBarButton2.Text = "Button2";
            this.outlookBar1.Buttons.Add(outlookBarButton1);
            this.outlookBar1.Buttons.Add(outlookBarButton2);
            this.outlookBar1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.outlookBar1.DrawBorders = true;
            this.outlookBar1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(66)))), ((int)(((byte)(139)))));
            this.outlookBar1.ForeColorSelected = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(66)))), ((int)(((byte)(139)))));
            this.outlookBar1.Location = new System.Drawing.Point(0, 271);
            this.outlookBar1.MinimumSize = new System.Drawing.Size(16, 40);
            this.outlookBar1.Name = "outlookBar1";
            this.outlookBar1.OutlookBarLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(111)))), ((int)(((byte)(157)))), ((int)(((byte)(217)))));
            this.outlookBar1.RemoveTopBorder = true;
            this.outlookBar1.Renderer = AC.ExtendedRenderer.Navigator.Renderer.Krypton;
            this.outlookBar1.Size = new System.Drawing.Size(179, 104);
            this.outlookBar1.TabIndex = 11;
            this.outlookBar1.Text = "outlookBar1";
            this.outlookBar1.ButtonClicked += new AC.ExtendedRenderer.Navigator.OutlookBar.ButtonClickedEventHandler(this.outlookBar1_ButtonClicked_1);
            // 
            // kryptonHeaderCollapser
            // 
            this.kryptonHeaderCollapser.ButtonSpecs.AddRange(new ComponentFactory.Krypton.Toolkit.ButtonSpecAny[] {
            this.buttonSpecAny1});
            this.kryptonHeaderCollapser.Dock = System.Windows.Forms.DockStyle.Top;
            this.kryptonHeaderCollapser.Location = new System.Drawing.Point(0, 0);
            this.kryptonHeaderCollapser.Name = "kryptonHeaderCollapser";
            this.kryptonHeaderCollapser.Size = new System.Drawing.Size(179, 30);
            this.kryptonHeaderCollapser.StateNormal.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)(((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left)
                        | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.kryptonHeaderCollapser.TabIndex = 13;
            this.kryptonHeaderCollapser.Text = "  ";
            this.kryptonHeaderCollapser.Values.Description = "";
            this.kryptonHeaderCollapser.Values.Heading = "  ";
            this.kryptonHeaderCollapser.Values.Image = null;
            // 
            // buttonSpecAny1
            // 
            this.buttonSpecAny1.ExtraText = "";
            this.buttonSpecAny1.Image = null;
            this.buttonSpecAny1.Text = "";
            this.buttonSpecAny1.Type = ComponentFactory.Krypton.Toolkit.PaletteButtonSpecStyle.ArrowLeft;
            this.buttonSpecAny1.UniqueName = "C18E250E4E8343ADC18E250E4E8343AD";
            this.buttonSpecAny1.Click += new System.EventHandler(this.buttonSpecAny1_Click);
            // 
            // kryptonHeaderGroup
            // 
            this.kryptonHeaderGroup.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kryptonHeaderGroup.HeaderVisibleSecondary = false;
            this.kryptonHeaderGroup.Location = new System.Drawing.Point(0, 0);
            this.kryptonHeaderGroup.Name = "kryptonHeaderGroup";
            // 
            // kryptonHeaderGroup.Panel
            // 
            this.kryptonHeaderGroup.Panel.Controls.Add(this.kryptonEmptyTabControl2);
            this.kryptonHeaderGroup.Size = new System.Drawing.Size(489, 375);
            this.kryptonHeaderGroup.TabIndex = 1;
            this.kryptonHeaderGroup.Text = "  ";
            this.kryptonHeaderGroup.ValuesPrimary.Description = "";
            this.kryptonHeaderGroup.ValuesPrimary.Heading = "  ";
            this.kryptonHeaderGroup.ValuesPrimary.Image = ((System.Drawing.Image)(resources.GetObject("kryptonHeaderGroup.ValuesPrimary.Image")));
            this.kryptonHeaderGroup.ValuesSecondary.Description = "";
            this.kryptonHeaderGroup.ValuesSecondary.Heading = "Description";
            this.kryptonHeaderGroup.ValuesSecondary.Image = null;
            // 
            // kryptonEmptyTabControl2
            // 
            this.kryptonEmptyTabControl2.Controls.Add(this.tabPage1b);
            this.kryptonEmptyTabControl2.Controls.Add(this.tabPage2b);
            this.kryptonEmptyTabControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kryptonEmptyTabControl2.DrawBorder = false;
            this.kryptonEmptyTabControl2.Location = new System.Drawing.Point(0, 0);
            this.kryptonEmptyTabControl2.Margin = new System.Windows.Forms.Padding(0);
            this.kryptonEmptyTabControl2.Name = "kryptonEmptyTabControl2";
            this.kryptonEmptyTabControl2.SelectedIndex = 0;
            this.kryptonEmptyTabControl2.Size = new System.Drawing.Size(487, 343);
            this.kryptonEmptyTabControl2.TabIndex = 0;
            // 
            // tabPage1b
            // 
            this.tabPage1b.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.tabPage1b.Location = new System.Drawing.Point(4, 14);
            this.tabPage1b.Margin = new System.Windows.Forms.Padding(0);
            this.tabPage1b.Name = "tabPage1b";
            this.tabPage1b.Size = new System.Drawing.Size(479, 325);
            this.tabPage1b.TabIndex = 0;
            this.tabPage1b.Text = "tabPage1b";
            this.tabPage1b.UseVisualStyleBackColor = true;
            // 
            // tabPage2b
            // 
            this.tabPage2b.BackColor = System.Drawing.SystemColors.Window;
            this.tabPage2b.Location = new System.Drawing.Point(4, 14);
            this.tabPage2b.Margin = new System.Windows.Forms.Padding(0);
            this.tabPage2b.Name = "tabPage2b";
            this.tabPage2b.Size = new System.Drawing.Size(479, 347);
            this.tabPage2b.TabIndex = 1;
            this.tabPage2b.Text = "tabPage2b";
            this.tabPage2b.UseVisualStyleBackColor = true;
            // 
            // tabPage1
            // 
            this.tabPage1.Location = new System.Drawing.Point(0, 0);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Size = new System.Drawing.Size(200, 100);
            this.tabPage1.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Location = new System.Drawing.Point(0, 0);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Size = new System.Drawing.Size(200, 100);
            this.tabPage2.TabIndex = 0;
            // 
            // tabPage3
            // 
            this.tabPage3.Location = new System.Drawing.Point(0, 0);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(200, 100);
            this.tabPage3.TabIndex = 0;
            // 
            // tabPage4
            // 
            this.tabPage4.Location = new System.Drawing.Point(0, 0);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(200, 100);
            this.tabPage4.TabIndex = 0;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.statusStrip1.Location = new System.Drawing.Point(0, 424);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.ManagerRenderMode;
            this.statusStrip1.Size = new System.Drawing.Size(668, 22);
            this.statusStrip1.TabIndex = 5;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(668, 446);
            this.Controls.Add(this.toolStripContainer1);
            this.Controls.Add(this.statusStrip1);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(257, 348);
            this.Name = "Form1";
            this.Text = "$safeprojectname$";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.toolStrip.ResumeLayout(false);
            this.toolStrip.PerformLayout();
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.toolStripContainer1.ContentPanel.ResumeLayout(false);
            this.toolStripContainer1.TopToolStripPanel.ResumeLayout(false);
            this.toolStripContainer1.TopToolStripPanel.PerformLayout();
            this.toolStripContainer1.ResumeLayout(false);
            this.toolStripContainer1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.KryptonSplitContainerMain.Panel1)).EndInit();
            this.KryptonSplitContainerMain.Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.KryptonSplitContainerMain.Panel2)).EndInit();
            this.KryptonSplitContainerMain.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.KryptonSplitContainerMain)).EndInit();
            this.KryptonSplitContainerMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanelMain)).EndInit();
            this.kryptonPanelMain.ResumeLayout(false);
            this.kryptonPanelMain.PerformLayout();
            this.kryptonEmptyTabControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.kryptonHeaderGroup.Panel)).EndInit();
            this.kryptonHeaderGroup.Panel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.kryptonHeaderGroup)).EndInit();
            this.kryptonHeaderGroup.ResumeLayout(false);
            this.kryptonEmptyTabControl2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip;
        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolStripContainer toolStripContainer1;
        private ComponentFactory.Krypton.Toolkit.KryptonPanel kryptonPanelMain;
        private ComponentFactory.Krypton.Toolkit.KryptonManager kryptonManager;
        private ComponentFactory.Krypton.Toolkit.KryptonSplitContainer KryptonSplitContainerMain;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private AC.ExtendedRenderer.Navigator.OutlookBar outlookBar1;
        private AC.ExtendedRenderer.Navigator.KryptonEmptyTabControl kryptonEmptyTabControl1;
        private System.Windows.Forms.TabPage tabPage1a;
        private System.Windows.Forms.TabPage tabPage2a;
        private ComponentFactory.Krypton.Toolkit.KryptonHeader kryptonHeaderCollapser;
        private ComponentFactory.Krypton.Toolkit.ButtonSpecAny buttonSpecAny1;
        private ComponentFactory.Krypton.Toolkit.KryptonHeaderGroup kryptonHeaderGroup;
        private AC.ExtendedRenderer.Navigator.KryptonEmptyTabControl kryptonEmptyTabControl2;
        private System.Windows.Forms.TabPage tabPage1b;
        private System.Windows.Forms.TabPage tabPage2b;
        private System.Windows.Forms.ToolStripButton tsbExit;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem closeToolStripMenuItem;
        private System.Windows.Forms.StatusStrip statusStrip1;

    }
}

